<div class="container">
        <h2>Acheter un Ticket</h2>
        <form action="<?php echo e(route('acheter-ticket')); ?>" method="post">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="utilisateur_id">Utilisateur</label>
                <input name="utilisateur_id" value="<?php echo e(Auth::user()->id); ?>" class="form-control" readonly/>
            </div>

            <div class="form-group">
                <label for="heure_debut">Heure de début:</label>
                <input type="time" name="heure_debut" class="form-control" placeholder="Heure de début">
            </div>



            <div class="form-group">
                <label for="montant">Montant:</label>
                <input type="text" name="montant" class="form-control" placeholder="Montant">
            </div>

            <button type="submit" class="btn btn-primary">Acheter le Ticket</button>
        </form>
    </div>
<?php /**PATH C:\Users\Administrateur\Desktop\spy2\resources\views/acheter_ticket.blade.php ENDPATH**/ ?>