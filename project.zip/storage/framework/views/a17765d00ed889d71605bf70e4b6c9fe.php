<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body>

    <script>
        // Optionally, you can add a script to trigger the print dialog when the page loads
        function print_page(){

                window.print();
                setDateTime();

        }

        // Function to set the date and time in the table
        function setDateTime() {
            var currentDate = new Date();
            var formattedDate = currentDate.toLocaleDateString('en-GB'); // Format: d/m/y
            var formattedTime = currentDate.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' }); // Format: h:m

            // Set the formatted date and time in respective td elements
            document.getElementById('dateTd').innerHTML = formattedDate;
            document.getElementById('timeTd').innerHTML = formattedTime;
        }
    </script>
    <div>
        <h1 class="text-center">Ticket</h1>
    </div>

    <table class="table table-success table-striped">
        <thead>
            <tr>
                <th scope="col">Categorie</th>
                <th scope="col">Prix</th>
                <th scope="col">Date</th>
                <th scope="col">Time</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($libelle); ?></td>
                <td><?php echo e($montant); ?></td>
                <td id="dateTd"></td>
                <td id="timeTd"></td>
            </tr>
        </tbody>
    </table>
    <div>
        <h1 class="text-center">Merci de votre visite</h1>
    </div>
    <form action="<?php echo e(route('acheter-ticket')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" value="<?php echo e($montant); ?>" name="montant" />
        <button type="submit" class="btn btn-success" onclick="print_page()">Tirer ticket</button>
    </form>

</body>
</html>
<?php /**PATH C:\Users\Administrateur\Desktop\spy2\resources\views/confirmation.blade.php ENDPATH**/ ?>